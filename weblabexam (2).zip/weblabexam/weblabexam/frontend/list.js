import React, { useEffect, useState } from 'react';
import axios from 'axios';

const list = () => {
  const [articles, setArticles] = useState([]);

  useEffect(() => {
    const fetchArticles = async () => {
      try {
        const response = await axios.get('/api/articles');
        setArticles(response.data);
      } catch (err) {
        console.error('Error fetching articles:', err);
      }
    };
    fetchArticles();
  }, []);

  return (
    <div>
      <h2>All Articles</h2>
      <ul>
        {articles.map(article => (
          <li key={article._id}>
            <strong>Name:</strong> {article.name} <br />
            <strong>Category:</strong> {article.category} <br />
            <strong>Creator:</strong> {article.creatorName} <br />
            <strong>Date Created:</strong> {new Date(article.dateCreated).toLocaleDateString()}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default list;
