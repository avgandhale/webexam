import React, { useState } from 'react';
import axios from 'axios';

const AddArticleForm = () => {
  const [name, setName] = useState('');
  const [category, setCategory] = useState('');
  const [creatorName, setCreatorName] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('/api/article', { name, category, creatorName });
      alert('Article added successfully');
      setName('');
      setCategory('');
      setCreatorName('');
    } catch (err) {
      console.error('Error adding article:', err);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input type="text" placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} required />
      <select value={category} onChange={(e) => setCategory(e.target.value)} required>
        <option value="">Select Category</option>
        <option value="painting">Painting</option>
        <option value="sculpture">Sculpture</option>
        <option value="artifact">Artifact</option>
      </select>
      <input type="text" placeholder="Creator Name" value={creatorName} onChange={(e) => setCreatorName(e.target.value)} required />
      <button type="submit">Add Article</button>
    </form>
  );
};

export default form;
