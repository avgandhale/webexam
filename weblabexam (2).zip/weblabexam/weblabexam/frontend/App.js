import React from 'react';
import AddArticleForm from './AddArticleForm';
import list from './list';

function App() {
  return (
    <div className="App">
      <h1>Museum Management</h1>
      <AddArticleForm />
      <list />
    </div>
  );
}

export default App;


 

