import React, {useState} from 'react';
import axios from 'axios';

const formupdate= ({article}) => {
  const [name, setName] = useState(article.name);
  const [category, setCategory] = useState(article.category);
  const [creatorName, setCreatorName] = useState(article.creatorName);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`/api/articles/${article._id}`, { name, category, creatorName });
      alert('Form updated successfully');
    } catch (err) {
      console.error('Error updating article:', err);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input type="text" value={name} onChange={(e) => setName(e.target.value)} required />
      <select value={category} onChange={(e) => setCategory(e.target.value)} required>
        <option value="painting">Painting</option>
        <option value="sculpture">Sculpture</option>
        <option value="artifact">Artifact</option>
      </select>
      <input type="text" value={creatorName} onChange={(e) => setCreatorName(e.target.value)} required />
      <button type="submit">Update Article</button>
    </form>
  );
};

export default formupdate;
