import React from 'react';
import { Link } from 'react-router-dom';
import { Container, Button } from 'react-bootstrap';
const Home = () => (
<Container>
  <h1>Museum Management</h1>
  <Link to="/update">
  <Button variant="primary">Update id</Button>
  </Link>
  <Link to="/id">
  <Button variant="secondary">View Id</Button>
  </Link>
  </Container>
  );
   export default Home;